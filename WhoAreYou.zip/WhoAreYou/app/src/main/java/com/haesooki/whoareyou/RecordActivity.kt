package com.haesooki.whoareyou

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class RecordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)
    }

    override fun onStart() {
        super.onStart()

        val startButton = findViewById<Button>(R.id.start_recording)
        val stopButton = findViewById<Button>(R.id.stop_recording)
        val screen = findViewById<TextView>(R.id.screen)

        startButton.setOnClickListener {
            screen.text = "Now Recording..."
        }
        stopButton!!.setOnClickListener {
            val intent = Intent(this, SaveActivity::class.java)

            screen.text = "Now Saving..."
            startActivity(intent)
            finish()
        }
    }
}
