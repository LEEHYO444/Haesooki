package com.haesooki.whoareyou

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import android.media.MediaPlayer
import android.widget.Button


class RecognizeActivity : AppCompatActivity() {
    val names:Array<String> = arrayOf("lee", "choi", "jung", "park", "none")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recognize)

        val resultButton = findViewById<Button>(R.id.result_button)
        var ind = 0

        resultButton.setOnClickListener {
            showLoadingDialog(names[ind])
            if (ind != 4) ind++
        }
    }

    private fun showLoadingDialog(name: String) {
        val dialog = LoadingDialog(this@RecognizeActivity)
        CoroutineScope(Dispatchers.Main).launch {
            val result = findViewById<TextView>(R.id.result)
            result.text = ""

            dialog.show()
            delay(5000)
            dialog.dismiss()

            when(name) {
                "lee" -> {
                    val mediaPlayer = MediaPlayer.create(this@RecognizeActivity,R.raw.voice_lee)
                    result.text = "이효준입니다."
                    mediaPlayer.start()
                }
                "choi" -> {
                    val mediaPlayer = MediaPlayer.create(this@RecognizeActivity,R.raw.voice_choi)
                    result.text = "최진혁입니다."
                    mediaPlayer.start()
                }
                "jung" -> {
                    val mediaPlayer = MediaPlayer.create(this@RecognizeActivity,R.raw.voice_jung)
                    result.text = "정윤서입니다."
                    mediaPlayer.start()
                }
                "park" -> {
                    val mediaPlayer = MediaPlayer.create(this@RecognizeActivity,R.raw.voice_park)
                    result.text = "박성민입니다."
                    mediaPlayer.start()
                }
                else -> {
                    val mediaPlayer = MediaPlayer.create(this@RecognizeActivity,R.raw.voice_none)
                    result.text = "등록되지 않은 사람입니다."
                    mediaPlayer.start()
                }
            }
        }
    }
}
